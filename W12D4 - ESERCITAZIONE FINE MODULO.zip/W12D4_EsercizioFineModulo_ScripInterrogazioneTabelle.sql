-- 1) VERIFICARE CHE I CAMPI DEFINITI COME PK SIANO UNIVOCI.

-- TABELLA CATEGORIA
SELECT * 
FROM categorie;

-- TOTALE 5 RIGHE

SELECT DISTINCT
idCategoria
FROM categorie;
-- TOTALE CONTEGGIO 5


-- TABELLA CLIENTI
SELECT * 
FROM clienti;
-- TOTALE 100 RIGHE

SELECT DISTINCT
idCliente
FROM clienti;
-- TOTALE CONTEGGIO 100


-- TABELLA NAZIONI
SELECT * 
FROM nazioni;
-- TOTALE 11 RIGHE

SELECT DISTINCT
IdNazione
FROM nazioni;
-- TOTALE CONTEGGIO 11

-- TABELLA PRODOTTI
SELECT * 
FROM prodotti;
-- TOTALE 500 RIGHE

SELECT DISTINCT
IdProdotto
FROM prodotti;
-- TOTALE CONTEGGIO 500


-- TABELLA PRODOTTI
SELECT * 
FROM regioni;
-- TOTALE 6 RIGHE

SELECT DISTINCT
Idregione
FROM regioni;
-- TOTALE CONTEGGIO 6


-- TABELLA VENDITE
SELECT * 
FROM vendite;
-- TOTALE 4918 RIGHE

SELECT DISTINCT
idVendita
, IdRiga
FROM vendite;
-- TOTALE CONTEGGIO 4918

-- 2 ESPORRE L'ELENCO DELLE TRANSAZIONI INDICANDO NEL RESULT SET IL CODICE DOCUMENTO, LA DATA, IL NOME DEL PRODOTTO
--   LA CATEGORIA DEL PRODOTTO, IL NOME DELLO STATO, IL NOME DELLA REGIONE E UN CAMPO BOOLEANO VALORIZZATO IN BASE
--   ALLA CONDIZIONE CHE SIANO PASSATI PIU' DI 180 GIORNI DALLA DATA DI VENDITA O MENO

SELECT
 A.idVendita AS Nr_Ordine
,IdRiga AS Nr_Riga
,A.data_ordine AS Data_Ordine
,B.DescrizioneProdotto AS Prodotto
,C.NomeCategoria AS Categoria
,E.NomeNazione AS Nazione
,F.DescrizioneRegione AS Regione
,CASE WHEN DATEDIFF(CURDATE(),A.data_ordine)> 180 THEN 'T' ELSE 'F' END AS OLTRE_180GG
FROM vendite A 
INNER JOIN prodotti B 
ON A.IdProdotto=B.idProdotto
INNER JOIN categorie C 
ON B.IdCategoria=C.idCategoria
INNER JOIN clienti D
ON A.IdCliente=D.idCliente
INNER JOIN nazioni E 
ON D.IdNazione=E.idNazione
INNER JOIN regioni F 
ON E.IdRegione=F.idRegione;




-- 3 ESPORRE L'ELENCO DEI PRODOTTI CHE HANNO VENDUTO, IN TOTALE, UNA QUANTITA' MAGGIORE DELLA MEDIA
--   DELLE VENDITE REALIZZATE NELL'ULTIMO ANNO CENSITO. NEL RESULT SET DEVONO COMPARIRE SOLO IL CODICE PRODOTTO E IL TOTALE VENDUTO

SELECT 
ID_PRODOTTO
, TOT_QUANTITA
FROM(
SELECT 
idprodotto
, YEAR(data_ordine) AS ANNO
, AVG(Quantita) AS VENDITA_MEDIA
FROM vendite
GROUP BY IdProdotto, YEAR(data_ordine)
HAVING ANNO = (SELECT YEAR(data_ordine) FROM vendite ORDER BY YEAR(data_ordine) DESC LIMIT 1 )) AS A
INNER JOIN (
SELECT 
IdProdotto AS ID_PRODOTTO
,SUM(Quantita) AS TOT_QUANTITA
FROM vendite
GROUP BY IdProdotto) AS B
ON A.idprodotto = B.ID_PRODOTTO
WHERE TOT_QUANTITA>VENDITA_MEDIA;

-- 4) ESPORRE L'ELENCO DEI PRODOTTI VENDUTI E PER OGNUNO DI QUESTI IL FATTURATO TOTALE PER ANNO

SELECT 
A.DescrizioneProdotto AS PRODOTTO
,YEAR(B.data_ordine) AS ANNO
-- ,B.Quantita
-- ,B.Prezzo
, SUM(B.Quantita*B.Prezzo) AS TOTALE
FROM prodotti A 
INNER JOIN vendite B
ON A.idProdotto=B.IdProdotto
GROUP BY A.DescrizioneProdotto, YEAR(B.data_ordine) 
ORDER BY A.DescrizioneProdotto, YEAR(B.data_ordine);


-- 5) ESPORRE IL FATTURATO TOALE PER STATO PER ANNO. ORDINA ILO RISULTATO PER DATA E PER FATTURATO DESCRESCENTE

SELECT 
C.NomeNazione AS NAZIONE
, YEAR(A.data_ordine) AS ANNO
-- , A.Quantita	
-- , A.Prezzo
, SUM(A.Quantita*A.Prezzo) AS FATTURATO_TOTALE
FROM vendite A 
INNER JOIN clienti B
ON A.IdCliente=B.idCliente
INNER JOIN nazioni C 
ON B.IdNazione=C.idNazione
GROUP BY C.NomeNazione, YEAR(A.data_ordine)
ORDER BY YEAR(A.data_ordine) DESC, SUM(A.Quantita*A.Prezzo) DESC;


-- 6) RISPONDERE ALLA SEGUENTE DOMANDA: QUAL E' LA CATEGORIA DI ARTICOLI MAGGIORMENTE RICHIESTA SUL MERCATO?
-- la categora maggiromente richiesta sono i "giochi da tavola" con 2317 pezzi venduti
SELECT 
 C.NomeCategoria AS CATEGORIA
,SUM(B.Quantita) AS TOTALE_QUANTITA
FROM prodotti A 
INNER JOIN vendite B
ON A.idProdotto=B.IdProdotto
INNER JOIN categorie C 
ON A.idCategoria=C.idCategoria 
GROUP BY C.NomeCategoria
ORDER BY SUM(B.Quantita) DESC;


-- 7) 	RISPONDERE ALLA SEGUENTE DOMANDA: QUALI SONO I PRODOTTI INVENDUTI?
--  Non esistono prodotti invenduti

-- SOLUZIONE 1: left outer join tra tabella prodotti e tabella vendite filtrando i valori NULL della tabella vendite
SELECT 
A.DescrizioneProdotto
FROM prodotti A 
LEFT OUTER JOIN vendite B 
ON A.idProdotto=B.IdProdotto
WHERE B.idVendita IS NULL;	

-- SOLUZIONE 2. filtro dei codici prodotto che non sono presenti nella tabella vendite

SELECT 
DescrizioneProdotto
FROM prodotti
WHERE idProdotto NOT IN (SELECT DISTINCT idProdotto FROM vendite);



-- 8) CREARE UNA VISTA SUI PRODOTTI IN MODO TALE DA ESPORRE UNA "VERSIONE DENORMALIZZATA" DELLE INFORMAZIONI UTILI

CREATE VIEW MV_elenco_prodotti AS
SELECT 
A.idProdotto
,A.DescrizioneProdotto
,B.NomeCategoria
FROM prodotti A 
INNER JOIN categorie B 
ON A.IdCategoria=B.idCategoria
ORDER BY A.DescrizioneProdotto;


SELECT * FROM mv_elenco_prodotti;

-- 9) CREARE UNA VISTA CON PER LE INFORMAZIONI GEOGRAFICHE

SELECT 
A.DescrizioneProdotto AS PRODOTTO
,C.NomeCategoria AS CATEGORIA
,E.NomeNazione AS NAZIONE
,F.DescrizioneRegione AS REGIONE
,SUM(B.Quantita) AS QUANTITA_VENDUTA
,AVG(B.Prezzo) AS PREZZO_MEDIO
,SUM(B.Quantita*B.Prezzo) AS TOTALE_FATTURATO
FROM prodotti A
INNER JOIN vendite B
ON A.idProdotto = B.IdProdotto
INNER JOIN categorie C 
ON A.IdCategoria=C.idCategoria
INNER JOIN clienti D 
ON B.IdCliente=D.idCliente
INNER JOIN nazioni E	
ON D.IdNazione=E.idNazione
INNER JOIN regioni F	
ON E.IdRegione=F.idRegione
GROUP BY A.DescrizioneProdotto, C.NomeCategoria, E.NomeNazione, F.DescrizioneRegione
